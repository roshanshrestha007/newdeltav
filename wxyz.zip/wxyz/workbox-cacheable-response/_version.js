"use strict";
// @ts-ignore
try {
    self['workbox:cacheable-response:6.5.4'] && _();
}
catch (e) { }
