# Changelog

## `4.0.0`

* **Breaking Change**: Removed support for Node `<12.x`