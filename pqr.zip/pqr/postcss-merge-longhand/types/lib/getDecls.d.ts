declare function _exports(rule: import('postcss').Rule, properties: string[]): import('postcss').Declaration[];
export = _exports;
