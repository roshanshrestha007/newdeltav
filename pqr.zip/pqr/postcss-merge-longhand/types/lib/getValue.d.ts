declare function _exports({ value }: import('postcss').Declaration): string;
export = _exports;
