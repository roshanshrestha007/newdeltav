module.exports = require('./every');
